﻿//namespace EmployeeManagementSystem.API.DependencyInjection
//{
//    public class InfrastructureDI
//    {
//    }
//}
