﻿namespace EmployeeManagementSystem.Application.CQRS.Handlers
{
    public class UpdateEmployeeCommand
    {
    }
}