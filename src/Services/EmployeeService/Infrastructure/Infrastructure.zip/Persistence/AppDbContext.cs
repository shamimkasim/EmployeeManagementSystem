using System.Data;
using EmployeeManagementSystem.Domain.Entities;
using EmployeeManagementSystem.Domain.ValueObjects;
using Microsoft.EntityFrameworkCore;

namespace EmployeeManagementSystem.Infrastructure.Persistence
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Role> Roles { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Employee>()
                .HasOne(e => e.Role)  // Employee has one Role
                .WithMany()            // Role can be assigned to multiple Employees
                .HasForeignKey(e => e.RoleId) // Ensure RoleId is the Foreign Key
                .IsRequired();

            modelBuilder.Entity<PhoneNumber>().HasNoKey(); // Keep existing PhoneNumber config
        }

    }
}
