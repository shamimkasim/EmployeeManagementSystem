using EmployeeManagementSystem.Domain.Entities;
using EmployeeManagementSystem.Domain.Enums;
using EmployeeManagementSystem.Domain.ValueObjects;
using EmployeeManagementSystem.Domain.Guards;
using System;

namespace EmployeeManagementSystem.Domain.Factories
{
    public static class EmployeeFactory
    {
        public static Employee Create(string firstName, string lastName, string email, string documentNumber,
            PhoneNumber phoneNumber, DateTime dateOfBirth, EmployeeRole role, Guid? managerId, string passwordHash)
        {
            Guard.AgainstNullOrEmpty(firstName, "First Name");
            Guard.AgainstNullOrEmpty(lastName, "Last Name");
            Guard.AgainstNullOrEmpty(email, "Email");
            Guard.AgainstEmailFormat(email, "Email");
            Guard.AgainstNullOrEmpty(documentNumber, "Document Number");
            Guard.AgainstUnderAge(dateOfBirth, 18, "Date of Birth");
            Guard.AgainstNullOrEmpty(passwordHash, "Password Hash");

            return new Employee(
                Guid.NewGuid(),
                firstName,
                lastName,
                email,
                documentNumber,
                phoneNumber,
                dateOfBirth,
                GetRoleIdFromEnum(role),  
                managerId,
                passwordHash
            );
        }

        
        private static Guid GetRoleIdFromEnum(EmployeeRole role)
        {
            return role switch
            {
                EmployeeRole.Admin => new Guid("11111111-1111-1111-1111-111111111111"),  // Replace with actual GUID
                EmployeeRole.Manager => new Guid("22222222-2222-2222-2222-222222222222"),  // Replace with actual GUID
                _ => throw new ArgumentException("Invalid EmployeeRole")
            };
        }
    }
}
