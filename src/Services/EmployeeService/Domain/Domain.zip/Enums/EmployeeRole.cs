﻿namespace EmployeeManagementSystem.Domain.Enums
{
    public enum EmployeeRole
    {
        Employee,
        Manager,
        Director,
        Admin
    }

}
